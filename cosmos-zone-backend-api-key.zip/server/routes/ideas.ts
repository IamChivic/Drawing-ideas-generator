import type { RequestHandler } from "express";
import { z } from "zod";

const MODEL = "gemini-2.0-flash";
const GOOGLE_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

const requestSchema = z.object({
  prompt: z.string().min(1).max(140),
  tone: z.string().min(1).max(120),
  count: z.number().int().min(3).max(5),
  mode: z.enum(["prompt", "random"]).default("prompt"),
});

interface GeminiCandidatePart {
  text?: string;
}

interface GeminiResponse {
  candidates?: Array<{
    content?: {
      parts?: GeminiCandidatePart[];
    };
  }>;
  error?: {
    message?: string;
    code?: number;
  };
}

interface Idea {
  title: string;
  description: string;
}

function buildInstruction(prompt: string, tone: string, count: number): string {
  return `You are MuseSpark, an imaginative drawing prompt generator. Create ${count} distinct drawing ideas inspired by "${prompt}" with a ${tone} tone. ` +
    `Reply strictly as JSON following {"ideas":[{"title":"short creative title","description":"rich, two-sentence description with concrete visual cues"}...]}. ` +
    `Avoid markdown, numbering, or additional properties. Focus on composition, lighting, color palette, and storytelling hooks for each idea.`;
}

function parseIdeas(rawText: string, requestedCount: number): Idea[] {
  const trimmed = rawText.trim();
  if (!trimmed) {
    return [];
  }

  const attemptJson = () => {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    if (Array.isArray(parsed?.ideas)) {
      return parsed.ideas;
    }
    return null;
  };

  try {
    const jsonResult = attemptJson();
    if (jsonResult) {
      return normalizeIdeas(jsonResult, requestedCount);
    }
  } catch (_error) {
    // swallow JSON parse errors and fall back to heuristic parsing
  }

  const lines = trimmed
    .split(/\n+/)
    .map((line) => line.replace(/^[-*\d.\s]+/, "").trim())
    .filter(Boolean);

  const ideas = lines.map((entry, index) => {
    const [maybeTitle, ...rest] = entry.split(/[:–-]\s*/);
    const title = (maybeTitle || `Idea ${index + 1}`).trim();
    const description = rest.length ? rest.join(" ").trim() : title;
    return {
      title: sanitizeText(title || `Idea ${index + 1}`),
      description: sanitizeText(description || "A rich, atmospheric drawing concept."),
    };
  });

  return ideas.slice(0, requestedCount);
}

function normalizeIdeas(rawIdeas: unknown[], requestedCount: number): Idea[] {
  return rawIdeas
    .map((entry, index) => {
      if (typeof entry === "string") {
        return {
          title: sanitizeText(`Idea ${index + 1}`),
          description: sanitizeText(entry),
        };
      }

      if (entry && typeof entry === "object") {
        const title = "title" in entry ? String((entry as Record<string, unknown>).title ?? "") : "";
        const description =
          "description" in entry ? String((entry as Record<string, unknown>).description ?? "") : "";

        return {
          title: sanitizeText(title || `Idea ${index + 1}`),
          description: sanitizeText(description || "A compelling drawing concept."),
        };
      }

      return {
        title: sanitizeText(`Idea ${index + 1}`),
        description: sanitizeText("A vivid drawing prompt."),
      };
    })
    .filter((idea) => idea.title && idea.description)
    .slice(0, requestedCount);
}

function sanitizeText(value: string): string {
  return value.replace(/[\u0000-\u001f]+/g, "").trim();
}

export const handleGenerateIdeas: RequestHandler = async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "Gemini API key is not configured on the server." });
  }

  const parsed = requestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: "Invalid request payload.",
      details: parsed.error.flatten(),
    });
  }

  const { prompt, tone, count, mode } = parsed.data;

  const body = {
    contents: [
      {
        role: "user",
        parts: [{ text: buildInstruction(prompt, tone, count) }],
      },
    ],
    generationConfig: {
      temperature: mode === "random" ? 1.1 : 0.9,
      topP: 0.95,
      topK: 40,
    },
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);

  try {
    const response = await fetch(`${GOOGLE_ENDPOINT}?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    const data = (await response.json()) as GeminiResponse;

    if (!response.ok) {
      const message = data?.error?.message || response.statusText || "Gemini API request failed.";
      const statusCode = data?.error?.code && data.error.code >= 400 ? data.error.code : response.status;
      return res.status(statusCode || 502).json({ error: message });
    }

    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    const text = parts
      .map((part) => (typeof part.text === "string" ? part.text : ""))
      .join("\n")
      .trim();

    const ideas = parseIdeas(text, count);

    if (!ideas.length) {
      return res.status(502).json({ error: "Gemini response did not contain any ideas." });
    }

    return res.json({
      ideas,
      model: MODEL,
      count: ideas.length,
      tone,
    });
  } catch (error) {
    if ((error as Error)?.name === "AbortError") {
      return res.status(504).json({ error: "Gemini API request timed out." });
    }

    const message = (error as Error)?.message || "Unexpected error while generating ideas.";
    return res.status(502).json({ error: message });
  } finally {
    clearTimeout(timeout);
  }
};
