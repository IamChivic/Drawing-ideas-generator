const chips = [
  "Cyberpunk botanist studying neon flora",
  "Mythical guardian watching over bioluminescent tides",
  "Floating market drifting through aurora skies",
  "Whimsical forest tea party with tiny robots",
  "Architect sketching a city carved into crystal cliffs",
  "Dreamy underwater library lit by jellyfish lamps"
];

const tones = [
  { value: "vibrant", label: "Vibrant & dynamic" },
  { value: "dreamy", label: "Dreamy & ethereal" },
  { value: "moody", label: "Moody & dramatic" },
  { value: "whimsical", label: "Whimsical & playful" },
  { value: "minimalist", label: "Minimalist & elegant" }
];

const API_ENDPOINT = "/api/ideas";

const htmlEscapeMap = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};

function escapeHtml(input) {
  return String(input).replace(/[&<>"']/g, (char) => htmlEscapeMap[char]);
}

const ideaOutput = document.getElementById("ideaOutput");
const chipList = document.getElementById("chipList");
const ideaForm = document.getElementById("ideaForm");
const promptInput = document.getElementById("drawingPrompt");
const toneSelect = document.getElementById("toneSelect");
const randomButton = document.getElementById("randomIdeas");
const headerRandomButton = document.getElementById("headerRandom");

let currentController = null;

function setPlaceholder() {
  ideaOutput.innerHTML = `
    <div class="placeholder">
      <div class="placeholder__icon" aria-hidden="true">✨</div>
      <h2>Ideas will appear here</h2>
      <p>Describe what you feel like drawing or ask for a random burst to explore new creative territory.</p>
    </div>
  `;
}

function setLoading(message) {
  ideaOutput.innerHTML = `
    <div class="placeholder" role="status" aria-live="polite">
      <div class="loader"></div>
      <p>${escapeHtml(message)}</p>
    </div>
  `;
}

function setError(message) {
  ideaOutput.innerHTML = `
    <div class="error" role="alert">
      ${escapeHtml(message)}
    </div>
  `;
}

function renderIdeas(ideas, context) {
  const ideaMarkup = ideas
    .map((idea) => {
      const safeTitle = escapeHtml(idea.title);
      const safeDescription = escapeHtml(idea.description);
      const safeTone = escapeHtml(context.toneLabel);
      const safeModel = escapeHtml(context.model);
      return `
        <article class="idea-card">
          <h3 class="idea-card__title">${safeTitle}</h3>
          <p class="idea-card__description">${safeDescription}</p>
          <span class="idea-card__meta">Tone: ${safeTone} · Gemini model: ${safeModel}</span>
        </article>
      `;
    })
    .join("");

  const generatedAt = escapeHtml(
    new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  );

  ideaOutput.innerHTML = `
    <div class="idea-grid">${ideaMarkup}</div>
    <div class="idea-card__meta" style="margin-top: 1.5rem; text-align: center;">
      Generated ${escapeHtml(context.count)} idea${context.count > 1 ? "s" : ""} · ${generatedAt}
    </div>
  `;
}

function populateChips() {
  chipList.innerHTML = "";
  chips.forEach((label) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "chip";
    button.textContent = label;
    button.addEventListener("click", () => {
      promptInput.value = label;
      promptInput.focus({ preventScroll: true });
    });
    chipList.appendChild(button);
  });
}

async function fetchIdeas({ prompt, tone, count, mode }) {
  const controller = new AbortController();
  currentController = controller;

  const response = await fetch(API_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ prompt, tone, count, mode }),
    signal: controller.signal
  });

  const isJson = response.headers.get("content-type")?.includes("application/json");
  const payload = isJson ? await response.json() : await response.text();

  if (!response.ok) {
    const message =
      (isJson && payload?.error) ||
      (isJson && payload?.message) ||
      (typeof payload === "string" && payload) ||
      response.statusText ||
      "Unknown error";
    throw new Error(message);
  }

  return payload;
}

async function handleGeneration({ mode, count }) {
  const prompt = promptInput.value.trim();
  const toneValue = toneSelect.value;
  const toneOption = tones.find((item) => item.value === toneValue) || tones[0];

  if (!prompt) {
    setError("Describe what you feel like drawing first.");
    promptInput.focus();
    return;
  }

  if (currentController) {
    currentController.abort();
  }

  setLoading("Summoning fresh inspiration from MuseSpark...");

  try {
    const payload = await fetchIdeas({
      prompt,
      tone: toneOption.label,
      count,
      mode
    });

    const ideas = Array.isArray(payload?.ideas) ? payload.ideas : [];
    if (!ideas.length) {
      throw new Error("No ideas returned. Please try again.");
    }

    const toneLabel = payload?.tone || toneOption.label;
    const countLabel = typeof payload?.count === "number" ? payload.count : ideas.length;
    const modelLabel = payload?.model || "gemini-2.0-flash";

    renderIdeas(ideas, {
      toneLabel,
      count: countLabel,
      model: modelLabel
    });
  } catch (error) {
    if (error?.name === "AbortError") {
      return;
    }
    const message = error?.message || "Unable to generate ideas right now.";
    setError(message);
  } finally {
    currentController = null;
  }
}

function initEvents() {
  populateChips();
  setPlaceholder();

  ideaForm.addEventListener("submit", (event) => {
    event.preventDefault();
    handleGeneration({ mode: "prompt", count: 4 });
  });

  randomButton.addEventListener("click", () => {
    const randomChip = chips[Math.floor(Math.random() * chips.length)];
    const randomTone = tones[Math.floor(Math.random() * tones.length)];
    const count = 3 + Math.floor(Math.random() * 3);
    promptInput.value = randomChip;
    toneSelect.value = randomTone.value;
    handleGeneration({ mode: "random", count });
  });

  headerRandomButton.addEventListener("click", () => {
    randomButton.click();
  });
}

document.addEventListener("DOMContentLoaded", initEvents);
